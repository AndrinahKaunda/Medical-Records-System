from flask import Flask, render_template, redirect, url_for

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    from app.auth.routes import auth_bp
    app.register_blueprint(auth_bp)

    from app.patients_management.routes import patients_bp
    app.register_blueprint(patients_bp)

    from app.prescriptions.routes import prescriptions_bp
    app.register_blueprint(prescriptions_bp)

    from app.PDF.routes import pdf_routes
    app.register_blueprint(pdf_routes)

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)