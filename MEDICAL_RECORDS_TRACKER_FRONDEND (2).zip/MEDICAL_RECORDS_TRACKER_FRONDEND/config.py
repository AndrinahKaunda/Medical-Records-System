import os

# config.py


class Config:
    # Flask secret key
    SECRET_KEY = os.environ.get('SECRET_KEY', 'your_default_secret_key')

    # API endpoint for backend server
    API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:5000/api')

    # Other configuration variables can be added here

# Example usage:
# from config import Config
# api_url = Config.API_BASE_URL