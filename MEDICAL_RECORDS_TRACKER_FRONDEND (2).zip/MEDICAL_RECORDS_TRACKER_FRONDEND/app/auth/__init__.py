# app/auth/__init__.py

# This file marks the 'auth' directory as a Python package.
# You can also initialize authentication-related extensions here if needed.
