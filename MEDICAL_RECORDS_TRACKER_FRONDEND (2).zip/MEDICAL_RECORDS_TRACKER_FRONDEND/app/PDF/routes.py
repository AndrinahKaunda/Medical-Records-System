from flask import Blueprint, send_file, request, jsonify
import os

pdf_routes = Blueprint('pdf_routes', __name__)

PDF_FOLDER = os.path.join(os.getcwd(), 'pdf')

@pdf_routes.route('/pdf/<filename>', methods=['GET'])
def get_pdf(filename):
    file_path = os.path.join(PDF_FOLDER, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return jsonify({'error': 'File not found'}), 404

@pdf_routes.route('/pdf/upload', methods=['POST'])
def upload_pdf():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if file and file.filename.lower().endswith('.pdf'):
        save_path = os.path.join(PDF_FOLDER, file.filename)
        file.save(save_path)
        return jsonify({'message': 'File uploaded successfully'}), 201
    return jsonify({'error': 'Invalid file type'}), 400

@pdf_routes.route('/pdf')
def pdf_home():
    return "PDF Blueprint Home"