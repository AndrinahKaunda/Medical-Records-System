from flask import Blueprint, request, jsonify

visits_bp = Blueprint('visits', __name__)

@visits_bp.route('/visits', methods=['GET'])
def get_visits():
    # Placeholder: Replace with actual database query
    visits = [
        {"id": 1, "patient_id": 101, "date": "2024-06-01", "notes": "Routine checkup"},
        {"id": 2, "patient_id": 102, "date": "2024-06-02", "notes": "Follow-up visit"}
    ]
    return jsonify(visits)

@visits_bp.route('/visits', methods=['POST'])
def add_visit():
    data = request.get_json()
    # Placeholder: Insert visit into database
    # Return the created visit (mocked)
    new_visit = {
        "id": 3,
        "patient_id": data.get("patient_id"),
        "date": data.get("date"),
        "notes": data.get("notes")
    }
    return jsonify(new_visit), 201