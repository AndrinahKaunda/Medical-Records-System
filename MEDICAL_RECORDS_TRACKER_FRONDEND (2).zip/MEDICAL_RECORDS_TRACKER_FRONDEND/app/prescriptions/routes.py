from flask import Blueprint, request, jsonify

prescriptions_bp = Blueprint('prescriptions', __name__)

# Example route: Get all prescriptions
@prescriptions_bp.route('/prescriptions', methods=['GET'])
def get_prescriptions():
    # Placeholder: Replace with database query
    prescriptions = [
        {"id": 1, "patient": "John Doe", "medication": "Drug A", "dosage": "10mg"},
        {"id": 2, "patient": "Jane Smith", "medication": "Drug B", "dosage": "5mg"}
    ]
    return jsonify(prescriptions)

# Example route: Add a new prescription
@prescriptions_bp.route('/prescriptions', methods=['POST'])
def add_prescription():
    data = request.get_json()
    # Placeholder: Save to database
    return jsonify({"message": "Prescription added", "data": data}), 201