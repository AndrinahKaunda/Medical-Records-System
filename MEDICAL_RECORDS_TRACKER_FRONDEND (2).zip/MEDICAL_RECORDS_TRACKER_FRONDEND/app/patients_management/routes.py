from flask import Blueprint, request, jsonify

patients_bp = Blueprint('patients', __name__)

# Example route: Get all patients
@patients_bp.route('/patients', methods=['GET'])
def get_patients():
    # Placeholder: Replace with actual database query
    patients = [
        {"id": 1, "name": "John Doe", "age": 30},
        {"id": 2, "name": "Jane Smith", "age": 25}
    ]
    return jsonify(patients)

# Example route: Add a new patient
@patients_bp.route('/patients', methods=['POST'])
def add_patient():
    data = request.get_json()
    # Placeholder: Save patient to database
    return jsonify({"message": "Patient added", "patient": data}), 201

# Example route: Get a patient by ID
@patients_bp.route('/patients/<int:patient_id>', methods=['GET'])
def get_patient(patient_id):
    # Placeholder: Replace with actual database query
    patient = {"id": patient_id, "name": "John Doe", "age": 30}
    return jsonify(patient)