from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime

class UserBase(BaseModel):
    username: str
    email: str

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int
    is_active: bool

    class Config:
        orm_mode = True

class MedicalRecordBase(BaseModel):
    patient_id: int
    diagnosis: str
    treatment: str
    record_date: date

class MedicalRecordCreate(MedicalRecordBase):
    pass

class MedicalRecord(MedicalRecordBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

class PatientBase(BaseModel):
    first_name: str
    last_name: str
    date_of_birth: date

class PatientCreate(PatientBase):
    pass

class Patient(PatientBase):
    id: int
    medical_records: Optional[List[MedicalRecord]] = []

    class Config:
        orm_mode = True