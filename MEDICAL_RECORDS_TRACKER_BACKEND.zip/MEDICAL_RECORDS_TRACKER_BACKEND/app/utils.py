import uuid
from datetime import datetime

def generate_unique_id():
    """Generate a unique identifier using UUID4."""
    return str(uuid.uuid4())

def get_current_timestamp():
    """Return the current UTC timestamp as an ISO formatted string."""
    return datetime.utcnow().isoformat() + 'Z'

def validate_required_fields(data, required_fields):
    """
    Validate that all required fields are present in the data dictionary.
    Returns a tuple (is_valid, missing_fields).
    """
    missing = [field for field in required_fields if field not in data or data[field] is None]
    return (len(missing) == 0, missing)