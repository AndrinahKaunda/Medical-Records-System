from celery import Celery

# Initialize Celery app
celery_app = Celery(
    'medical_records_tracker',
    broker='redis://localhost:6379/0',
    backend='redis://localhost:6379/0'
)

@celery_app.task
def example_task(x, y):
    """A simple example task that adds two numbers."""
    return x + y