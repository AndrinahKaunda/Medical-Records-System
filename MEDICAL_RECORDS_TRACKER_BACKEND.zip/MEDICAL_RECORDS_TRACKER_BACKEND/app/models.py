from sqlalchemy import Column, Integer, String, Date, ForeignKey, Text
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()

class Patient(Base):
    __tablename__ = 'patients'
    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    date_of_birth = Column(Date, nullable=False)
    gender = Column(String(10))
    medical_records = relationship("Precautions", back_populates="patients")

class Precautions(Base):
    __tablename__ = 'precautions'
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey('patients.id'), nullable=False)
    diagnosis = Column(String(255), nullable=False)
    treatment = Column(Text)
    record_date = Column(Date, nullable=False)
    patient = relationship("Patient", back_populates="medical_records")
    
class visits(Base):
    __tablename__ = 'visits'
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Integer, default=1)  # 1 for active, 0 for inactive
    is_admin = Column(Integer, default=0)  # 1 for admin, 0 for regular user