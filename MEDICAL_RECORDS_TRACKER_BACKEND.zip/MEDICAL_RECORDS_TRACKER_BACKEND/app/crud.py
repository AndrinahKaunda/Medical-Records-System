from sqlalchemy.orm import Session
from . import models, schemas

# Create a new medical record
def create_medical_record(db: Session, record: schemas.MedicalRecordCreate):
    db_record = models.MedicalRecord(**record.dict())
    db.add(db_record)
    db.commit()
    db.refresh(db_record)
    return db_record

# Get a medical record by ID
def get_medical_record(db: Session, record_id: int):
    return db.query(models.MedicalRecord).filter(models.MedicalRecord.id == record_id).first()

# Get all medical records
def get_medical_records(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.MedicalRecord).offset(skip).limit(limit).all()

# Update a medical record
def update_medical_record(db: Session, record_id: int, record: schemas.MedicalRecordUpdate):
    db_record = db.query(models.MedicalRecord).filter(models.MedicalRecord.id == record_id).first()
    if db_record:
        for key, value in record.dict(exclude_unset=True).items():
            setattr(db_record, key, value)
        db.commit()
        db.refresh(db_record)
    return db_record

# Delete a medical record
def delete_medical_record(db: Session, record_id: int):
    db_record = db.query(models.MedicalRecord).filter(models.MedicalRecord.id == record_id).first()
    if db_record:
        db.delete(db_record)
        db.commit()
    return db_record