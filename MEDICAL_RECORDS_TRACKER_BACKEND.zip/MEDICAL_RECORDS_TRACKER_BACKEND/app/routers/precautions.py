from fastapi import APIRouter, HTTPException, Depends
from typing import List
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.database import get_db
from app import models

router = APIRouter(
    prefix="/precautions",
    tags=["precautions"]
)

class PrecautionBase(BaseModel):
    name: str
    description: str

class PrecautionCreate(PrecautionBase):
    pass

class Precaution(PrecautionBase):
    id: int

    class Config:
        orm_mode = True

@router.post("/", response_model=Precaution)
def create_precaution(precaution: PrecautionCreate, db: Session = Depends(get_db)):
    db_precaution = models.Precaution(**precaution.dict())
    db.add(db_precaution)
    db.commit()
    db.refresh(db_precaution)
    return db_precaution

@router.get("/", response_model=List[Precaution])
def read_precautions(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(models.Precaution).offset(skip).limit(limit).all()

@router.get("/{precaution_id}", response_model=Precaution)
def read_precaution(precaution_id: int, db: Session = Depends(get_db)):
    precaution = db.query(models.Precaution).filter(models.Precaution.id == precaution_id).first()
    if precaution is None:
        raise HTTPException(status_code=404, detail="Precaution not found")
    return precaution

@router.delete("/{precaution_id}", response_model=Precaution)
def delete_precaution(precaution_id: int, db: Session = Depends(get_db)):
    precaution = db.query(models.Precaution).filter(models.Precaution.id == precaution_id).first()
    if precaution is None:
        raise HTTPException(status_code=404, detail="Precaution not found")
    db.delete(precaution)
    db.commit()
    return precaution