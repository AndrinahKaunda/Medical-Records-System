from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from typing import List
from app import models, schemas, database

router = APIRouter(
    prefix="/visits",
    tags=["visits"]
)

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=schemas.Visit)
def create_visit(visit: schemas.VisitCreate, db: Session = Depends(get_db)):
    db_visit = models.Visit(**visit.dict())
    db.add(db_visit)
    db.commit()
    db.refresh(db_visit)
    return db_visit

@router.get("/", response_model=List[schemas.Visit])
def read_visits(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    visits = db.query(models.Visit).offset(skip).limit(limit).all()
    return visits

@router.get("/{visit_id}", response_model=schemas.Visit)
def read_visit(visit_id: int, db: Session = Depends(get_db)):
    visit = db.query(models.Visit).filter(models.Visit.id == visit_id).first()
    if visit is None:
        raise HTTPException(status_code=404, detail="Visit not found")
    return visit

@router.put("/{visit_id}", response_model=schemas.Visit)
def update_visit(visit_id: int, visit: schemas.VisitUpdate, db: Session = Depends(get_db)):
    db_visit = db.query(models.Visit).filter(models.Visit.id == visit_id).first()
    if db_visit is None:
        raise HTTPException(status_code=404, detail="Visit not found")
    for key, value in visit.dict(exclude_unset=True).items():
        setattr(db_visit, key, value)
    db.commit()
    db.refresh(db_visit)
    return db_visit

@router.delete("/{visit_id}", response_model=schemas.Visit)
def delete_visit(visit_id: int, db: Session = Depends(get_db)):
    db_visit = db.query(models.Visit).filter(models.Visit.id == visit_id).first()
    if db_visit is None:
        raise HTTPException(status_code=404, detail="Visit not found")
    db.delete(db_visit)
    db.commit()
    return db_visit